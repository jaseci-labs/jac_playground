class MyModule:
    @staticmethod
    def init():
        print("MyModule initialized!")

    @staticmethod
    def do_something():
        print("Doing something...")





