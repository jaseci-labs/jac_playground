# Print Hello, World!
print("Hello, World!")

a = 5
b = 3
sum_ab = a + b
print("Sum:", sum_ab)

num = 7
if num % 2 == 0:
    print(num, "is even")
else:
    print(num, "is odd")

# Loop through a list
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)

def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))