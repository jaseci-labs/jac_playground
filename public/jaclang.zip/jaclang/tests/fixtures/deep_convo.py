# flake8: noqa


"""python module which has dependencies on other module(html)."""

import html
