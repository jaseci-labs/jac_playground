# flake8: noqa

"""Python function."""

from __future__ import annotations


def my_print(x: object) -> None:
    """Print function."""
    print(x)
    return ""
