# flake8: noqa

"""Python function."""

from __future__ import annotations

class MyClass:
    pass

def my_print(x: object) -> None:
    """Print function."""
    print(x)
    return ""
